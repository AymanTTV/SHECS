package com.mycompany.crmapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

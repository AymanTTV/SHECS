import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyDwdOr_ELKlq279GnLxhksyRH6w39fGtb4",
            authDomain: "fir-h-e-c-s-smart-home-el-a8sn2v.firebaseapp.com",
            projectId: "s-h-e-c-s-smart-home-el-a8sn2v",
            storageBucket: "s-h-e-c-s-smart-home-el-a8sn2v.appspot.com",
            messagingSenderId: "156777445677",
            appId: "1:156777445677:web:fc280485f48c199bc8fba4"));
  } else {
    await Firebase.initializeApp();
  }
}

import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/auth/firebase_auth/auth_util.dart';

List<dynamic>? convertToCustomList(dynamic apiOutput) {
  // Check if the input is null
  if (apiOutput == null) {
    return null;
  }

  // Check if the input is a Map
  if (apiOutput is Map<String, dynamic>) {
    // Convert the Map to a List of JSON objects
    return apiOutput.entries
        .map((entry) => {'name': entry.key, 'value': entry.value})
        .toList();
  }

  // If the input is already a List of Maps, process each Map
  if (apiOutput is List<dynamic>) {
    List<dynamic> listOfJson = [];
    for (var item in apiOutput) {
      if (item is Map<String, dynamic>) {
        listOfJson.addAll(item.entries
            .map((entry) => {'name': entry.key, 'value': entry.value})
            .toList());
      }
    }
    return listOfJson;
  }

  // If the input is neither a Map nor a List, return null
  return null;
}

dynamic getValueFromListByName(
  List<dynamic>? jsonList,
  String name,
) {
  // Check if the input list is null
  if (jsonList == null) {
    return null;
  }

  // Iterate through the list of JSON objects
  for (var item in jsonList) {
    // Check if the item is a Map and contains the required 'name' key
    if (item is Map<String, dynamic> && item['name'] == name) {
      // Return the value associated with the 'name'
      return item['value'];
    }
  }

  // Return null if the name is not found in the list
  return null;
}

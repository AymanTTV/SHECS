import '/flutter_flow/flutter_flow_util.dart';
import 'user_details_widget.dart' show UserDetailsWidget;
import 'package:flutter/material.dart';

class UserDetailsModel extends FlutterFlowModel<UserDetailsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}

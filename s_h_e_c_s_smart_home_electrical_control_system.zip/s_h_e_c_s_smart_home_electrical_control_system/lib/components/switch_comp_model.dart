import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'switch_comp_widget.dart' show SwitchCompWidget;
import 'package:flutter/material.dart';

class SwitchCompModel extends FlutterFlowModel<SwitchCompWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for Switch widget.
  bool? switchValue;
  // Stores action output result for [Backend Call - API (Update  testroom)] action in Switch widget.
  ApiCallResponse? turnOnAllAction;
  // Stores action output result for [Backend Call - API (Update  testroom)] action in Switch widget.
  ApiCallResponse? turnOnFanAction;
  // Stores action output result for [Backend Call - API (Update  testroom)] action in Switch widget.
  ApiCallResponse? turnOnLightAction;
  // Stores action output result for [Backend Call - API (Update  testroom)] action in Switch widget.
  ApiCallResponse? turnOffAllAction;
  // Stores action output result for [Backend Call - API (Update  testroom)] action in Switch widget.
  ApiCallResponse? turnOffFanAction;
  // Stores action output result for [Backend Call - API (Update  testroom)] action in Switch widget.
  ApiCallResponse? turnOffLightAction;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}

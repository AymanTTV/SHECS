import '/flutter_flow/flutter_flow_util.dart';
import 'modal_message_widget.dart' show ModalMessageWidget;
import 'package:flutter/material.dart';

class ModalMessageModel extends FlutterFlowModel<ModalMessageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}

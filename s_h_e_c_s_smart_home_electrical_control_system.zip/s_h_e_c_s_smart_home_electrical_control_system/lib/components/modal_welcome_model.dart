import '/flutter_flow/flutter_flow_util.dart';
import 'modal_welcome_widget.dart' show ModalWelcomeWidget;
import 'package:flutter/material.dart';

class ModalWelcomeModel extends FlutterFlowModel<ModalWelcomeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}

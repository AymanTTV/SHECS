import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:flutter/material.dart';
import 'switch_comp_model.dart';
export 'switch_comp_model.dart';

class SwitchCompWidget extends StatefulWidget {
  const SwitchCompWidget({
    super.key,
    this.sValue,
    this.sName,
    this.testRoomDataList,
  });

  final dynamic sValue;
  final dynamic sName;
  final List<dynamic>? testRoomDataList;

  @override
  State<SwitchCompWidget> createState() => _SwitchCompWidgetState();
}

class _SwitchCompWidgetState extends State<SwitchCompWidget> {
  late SwitchCompModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SwitchCompModel());

    _model.switchValue = '${widget.sValue?.toString()}' == '1' ? true : false;
    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Switch.adaptive(
      value: _model.switchValue!,
      onChanged: (newValue) async {
        setState(() => _model.switchValue = newValue);
        if (newValue) {
          if ('${widget.sName?.toString()}' == 'All') {
            _model.turnOnAllAction = await UpdateTestroomCall.call(
              all: 1,
              fan: 1,
              light: 1,
            );

            if ((_model.turnOnAllAction?.succeeded ?? true)) {
              ScaffoldMessenger.of(context).clearSnackBars();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    'All is turn on.',
                    style: TextStyle(
                      color: FlutterFlowTheme.of(context).primaryText,
                    ),
                  ),
                  duration: const Duration(milliseconds: 4000),
                  backgroundColor: FlutterFlowTheme.of(context).secondary,
                ),
              );
              context.safePop();

              context.pushNamed('TestRoom');
            }
          } else if ('${widget.sName?.toString()}' == 'Fan') {
            _model.turnOnFanAction = await UpdateTestroomCall.call(
              fan: 1,
              all: functions.getValueFromListByName(
                  widget.testRoomDataList?.toList(), 'All'),
              light: functions.getValueFromListByName(
                  widget.testRoomDataList?.toList(), 'Light'),
            );

            if ((_model.turnOnFanAction?.succeeded ?? true)) {
              ScaffoldMessenger.of(context).clearSnackBars();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    'Fan is turn on.',
                    style: TextStyle(
                      color: FlutterFlowTheme.of(context).primaryText,
                    ),
                  ),
                  duration: const Duration(milliseconds: 4000),
                  backgroundColor: FlutterFlowTheme.of(context).secondary,
                ),
              );
            }
          } else if ('${widget.sName?.toString()}' == 'Light') {
            _model.turnOnLightAction = await UpdateTestroomCall.call(
              light: 1,
              all: functions.getValueFromListByName(
                  widget.testRoomDataList?.toList(), 'All'),
              fan: functions.getValueFromListByName(
                  widget.testRoomDataList?.toList(), 'Fan'),
            );

            if ((_model.turnOnLightAction?.succeeded ?? true)) {
              ScaffoldMessenger.of(context).clearSnackBars();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    'Light is turn on.',
                    style: TextStyle(
                      color: FlutterFlowTheme.of(context).primaryText,
                    ),
                  ),
                  duration: const Duration(milliseconds: 4000),
                  backgroundColor: FlutterFlowTheme.of(context).secondary,
                ),
              );
            }
          } else {
            ScaffoldMessenger.of(context).clearSnackBars();
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  'Try again.',
                  style: TextStyle(
                    color: FlutterFlowTheme.of(context).primaryText,
                  ),
                ),
                duration: const Duration(milliseconds: 4000),
                backgroundColor: FlutterFlowTheme.of(context).error,
              ),
            );
          }

          setState(() {});
        } else {
          if ('${widget.sName?.toString()}' == 'All') {
            _model.turnOffAllAction = await UpdateTestroomCall.call(
              all: 0,
              fan: 0,
              light: 0,
            );

            if ((_model.turnOffAllAction?.succeeded ?? true)) {
              ScaffoldMessenger.of(context).clearSnackBars();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    'All is turn off.',
                    style: TextStyle(
                      color: FlutterFlowTheme.of(context).primaryText,
                    ),
                  ),
                  duration: const Duration(milliseconds: 4000),
                  backgroundColor: FlutterFlowTheme.of(context).secondary,
                ),
              );
              context.safePop();

              context.pushNamed('TestRoom');
            }
          } else if ('${widget.sName?.toString()}' == 'Fan') {
            _model.turnOffFanAction = await UpdateTestroomCall.call(
              fan: 0,
              all: functions.getValueFromListByName(
                  widget.testRoomDataList?.toList(), 'All'),
              light: functions.getValueFromListByName(
                  widget.testRoomDataList?.toList(), 'Light'),
            );

            if ((_model.turnOffFanAction?.succeeded ?? true)) {
              ScaffoldMessenger.of(context).clearSnackBars();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    'Fan is turn off.',
                    style: TextStyle(
                      color: FlutterFlowTheme.of(context).primaryText,
                    ),
                  ),
                  duration: const Duration(milliseconds: 4000),
                  backgroundColor: FlutterFlowTheme.of(context).secondary,
                ),
              );
            }
          } else if ('${widget.sName?.toString()}' == 'Light') {
            _model.turnOffLightAction = await UpdateTestroomCall.call(
              all: functions.getValueFromListByName(
                  widget.testRoomDataList?.toList(), 'All'),
              light: 0,
              fan: functions.getValueFromListByName(
                  widget.testRoomDataList?.toList(), 'Fan'),
            );

            if ((_model.turnOffLightAction?.succeeded ?? true)) {
              ScaffoldMessenger.of(context).clearSnackBars();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    'Light is turn off.',
                    style: TextStyle(
                      color: FlutterFlowTheme.of(context).primaryText,
                    ),
                  ),
                  duration: const Duration(milliseconds: 4000),
                  backgroundColor: FlutterFlowTheme.of(context).secondary,
                ),
              );
            }
          } else {
            ScaffoldMessenger.of(context).clearSnackBars();
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  'Try again.',
                  style: TextStyle(
                    color: FlutterFlowTheme.of(context).primaryText,
                  ),
                ),
                duration: const Duration(milliseconds: 4000),
                backgroundColor: FlutterFlowTheme.of(context).error,
              ),
            );
          }

          setState(() {});
        }
      },
      activeColor: FlutterFlowTheme.of(context).primary,
      activeTrackColor: FlutterFlowTheme.of(context).accent1,
      inactiveTrackColor: FlutterFlowTheme.of(context).alternate,
      inactiveThumbColor: FlutterFlowTheme.of(context).secondaryText,
    );
  }
}

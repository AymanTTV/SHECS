import '/flutter_flow/flutter_flow_util.dart';
import 'modal_success_widget.dart' show ModalSuccessWidget;
import 'package:flutter/material.dart';

class ModalSuccessModel extends FlutterFlowModel<ModalSuccessWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
